export interface ConsoleResponseModel {
    consoleId: string;
    consoleName: string;
    releaseDate: string;
    price: number;
    quantityInStock: number;
    company: string;
    image: string;
}
